# How to install quiz application

- First press the green code button and download as a zip file

<img width="500" alt="image" src="https://github.com/user-attachments/assets/3180e511-9704-4653-9d10-7c067619a1eb" />

- Then unzip the folder by selecting extract all when you right click on the file, save into where you would like to store the file.

<img width="294" height="390" alt="image" src="https://github.com/user-attachments/assets/afa27446-1911-4394-8c75-1355d483c5db" />

- Next open up visual studio code and open a that folder that you just extracted

<img width="495" height="708" alt="image" src="https://github.com/user-attachments/assets/ea63c19f-a7fc-4de5-96d6-050dcd1e57d0" />

- If a secuirty message appears then just click that you trust the source :)

<img width="600" alt="image" src="https://github.com/user-attachments/assets/3cfff84c-2247-4c06-8cc1-43d4dae861e7" />

- All that is left to do now is to click on the quiz_app.py on the left hand side of the page and press the run play button on the right hand side.
  
<img width="875" height="214" alt="image" src="https://github.com/user-attachments/assets/46c3c24f-fad4-44a2-96fe-e9a5dfbe3ba1" />

- Hope you enjoy! XD
- Thankyou for taking my Quiz.
